package freirepalabras;

import CapaInterfaz.ComparacionPalabras;
import CapaInterfaz.EdicionPalabraCategoria;
import CapaNegocio.CapaNegocio;
import javax.swing.SwingUtilities;

public class FreirePalabras {

    public static void main(String[] args) {
        CapaNegocio negocio = new CapaNegocio();
        SwingUtilities.invokeLater(() -> {
            EdicionPalabraCategoria editor = new EdicionPalabraCategoria(negocio);
            editor.setVisible(true);
            ComparacionPalabras comparador = new ComparacionPalabras(negocio);
            comparador.setVisible(true);
        });
    }
}
