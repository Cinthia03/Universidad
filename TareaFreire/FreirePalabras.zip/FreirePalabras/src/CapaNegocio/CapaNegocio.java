package CapaNegocio;

import CapaDatos.CapaDatos;
import java.util.*;

public class CapaNegocio {
    public Set<String> obtenerCategorias() { return CapaDatos.obtenerCategorias(); }
    public List<String> obtenerPalabrasPorCategoria(String categoria) { return CapaDatos.obtenerPalabrasPorCategoria(categoria); }
    public void editarPalabra(String categoria, int indice, String nuevaPalabra) { CapaDatos.editarPalabra(categoria, indice, nuevaPalabra); }

    public String compararPalabras(String p1, String p2) {
        return p1.equalsIgnoreCase(p2) ? "Iguales" : "Diferentes";
    }

    public void guardarComparacion(String p1, String p2, String resultado) { CapaDatos.guardarComparacion(p1, p2, resultado); }

    public List<String> obtenerListaPalabra1() { return CapaDatos.getListaPalabra1(); }
    public List<String> obtenerListaPalabra2() { return CapaDatos.getListaPalabra2(); }
    public List<String> obtenerResultadosComparacion() { return CapaDatos.getResultadosComparacion(); }

    public void agregarPalabraACategoria(String categoria, String palabra) { CapaDatos.agregarPalabraACategoria(categoria, palabra); }
}