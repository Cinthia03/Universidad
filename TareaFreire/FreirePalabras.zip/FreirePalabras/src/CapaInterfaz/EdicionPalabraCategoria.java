package CapaInterfaz;

import CapaNegocio.CapaNegocio;
import javax.swing.*;
import java.awt.event.*;
import java.util.List;

public class EdicionPalabraCategoria extends javax.swing.JFrame {
    
    private CapaNegocio negocio;
    private DefaultListModel<String> modeloLista = new DefaultListModel<>();
    private String palabraSeleccionada = null;

    public EdicionPalabraCategoria(CapaNegocio negocio) {
        this.negocio = negocio;
        initComponents();
        cargarCategorias();
        configurarEventos();
    }
    
    private void cargarCategorias() {
        CMBCATEGORIAS.removeAllItems();
        for (String cat : negocio.obtenerCategorias()) {
            CMBCATEGORIAS.addItem(cat);
        }
        if (CMBCATEGORIAS.getItemCount() > 0) {
            CMBCATEGORIAS.setSelectedIndex(0);
            cargarPalabras();
        }
    }

    private void cargarPalabras() {
        String categoria = (String) CMBCATEGORIAS.getSelectedItem();
        modeloLista.clear();
        if (categoria != null) {
            List<String> palabras = negocio.obtenerPalabrasPorCategoria(categoria);
            for (String p : palabras) {
                modeloLista.addElement(p);
            }
            LISTPALABRAS.setModel(modeloLista);
        }
    }

    private void configurarEventos() {
        CMBCATEGORIAS.addActionListener(e -> cargarPalabras());
        LISTPALABRAS.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                palabraSeleccionada = LISTPALABRAS.getSelectedValue();
            }
        });

        BTNEDITAR.addActionListener(e -> {
            if (palabraSeleccionada != null) {
                TXTPALABRA.setText(palabraSeleccionada);
            }
        });

        BTNACTUALIZAR.addActionListener(e -> {
            int idx = LISTPALABRAS.getSelectedIndex();
            String nuevaPalabra = TXTPALABRA.getText().trim();
            String categoria = (String) CMBCATEGORIAS.getSelectedItem();
            if (idx >= 0 && !nuevaPalabra.isEmpty()) {
                negocio.editarPalabra(categoria, idx, nuevaPalabra);
                cargarPalabras();
                LISTPALABRAS.setSelectedIndex(idx);
                palabraSeleccionada = nuevaPalabra;
                TXTPALABRA.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione palabra y escriba nuevo valor.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CMBCATEGORIAS = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        LISTPALABRAS = new javax.swing.JList<>();
        LblCategoria = new javax.swing.JLabel();
        ListPalabras = new javax.swing.JLabel();
        BTNEDITAR = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        TXTPALABRA = new javax.swing.JTextField();
        BTNACTUALIZAR = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        CMBCATEGORIAS.setBackground(new java.awt.Color(248, 248, 248));
        CMBCATEGORIAS.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        CMBCATEGORIAS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        LISTPALABRAS.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(LISTPALABRAS);

        LblCategoria.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        LblCategoria.setText("CATEGORIA");

        ListPalabras.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ListPalabras.setText("LISTADO DE PALABRAS");

        BTNEDITAR.setBackground(new java.awt.Color(255, 255, 204));
        BTNEDITAR.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BTNEDITAR.setText("EDITAR");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("PALABRA");

        BTNACTUALIZAR.setBackground(new java.awt.Color(204, 255, 204));
        BTNACTUALIZAR.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BTNACTUALIZAR.setText("ACTUALIZAR");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("EDICION DE PALABRAS POR CATEGORIA");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LblCategoria)
                            .addComponent(CMBCATEGORIAS, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ListPalabras)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(105, 105, 105)
                        .addComponent(BTNEDITAR))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(TXTPALABRA, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(BTNACTUALIZAR)))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(TXTPALABRA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BTNACTUALIZAR))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LblCategoria)
                    .addComponent(ListPalabras)
                    .addComponent(BTNEDITAR))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CMBCATEGORIAS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
        );

        LblCategoria.getAccessibleContext().setAccessibleName("jLabel");

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNACTUALIZAR;
    private javax.swing.JButton BTNEDITAR;
    private javax.swing.JComboBox<String> CMBCATEGORIAS;
    private javax.swing.JList<String> LISTPALABRAS;
    private javax.swing.JLabel LblCategoria;
    private javax.swing.JLabel ListPalabras;
    private javax.swing.JTextField TXTPALABRA;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
