package CapaInterfaz;

import CapaNegocio.CapaNegocio;
import javax.swing.*;
import java.awt.event.*;
import java.util.List;

public class ComparacionPalabras extends javax.swing.JFrame {
    private CapaNegocio negocio;

    public ComparacionPalabras(CapaNegocio negocio) {
        this.negocio = negocio;
        initComponents();
        configurarEventos();
        cargarCategorias();
    }

    private void cargarCategorias() {
        CMBCATEGORIA.removeAllItems();
        for (String cat : negocio.obtenerCategorias()) {
            CMBCATEGORIA.addItem(cat);
        }
        if (CMBCATEGORIA.getItemCount() > 0) {
            CMBCATEGORIA.setSelectedIndex(0);
            cargarPalabras();
        }
    }

    private void cargarPalabras() {
        String categoria = (String) CMBCATEGORIA.getSelectedItem();
        DefaultListModel<String> modeloLista = new DefaultListModel<>();
        if (categoria != null) {
            List<String> palabras = negocio.obtenerPalabrasPorCategoria(categoria);
            for (String palabra : palabras) {
                modeloLista.addElement(palabra);
            }
        }
        LISTPALABRAS.setModel(modeloLista);
    }

    private void configurarEventos() {
        BTNCOMPARAR.addActionListener(e -> {
            String p1 = TXTPALABRA1.getText().trim();
            String p2 = TXTPALABRA2.getText().trim();
            String categoria = (String) CMBCATEGORIA.getSelectedItem();

            if (p1.isEmpty() || p2.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese ambas palabras.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String resultado = negocio.compararPalabras(p1, p2);
            negocio.guardarComparacion(p1, p2, resultado);

            negocio.agregarPalabraACategoria(categoria, p1);
            negocio.agregarPalabraACategoria(categoria, p2);

            cargarPalabras();
            actualizarHistorial();
            TXTPALABRA1.setText("");
            TXTPALABRA2.setText("");
        });

        CMBCATEGORIA.addActionListener(e -> cargarPalabras());
    }

    private void actualizarHistorial() {
        List<String> lista1 = negocio.obtenerListaPalabra1();
        List<String> lista2 = negocio.obtenerListaPalabra2();
        List<String> resultados = negocio.obtenerResultadosComparacion();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lista1.size(); i++) {
            sb.append(String.format("'%s' vs '%s' -> %s\n", lista1.get(i), lista2.get(i), resultados.get(i)));
        }
        TEXTAREA.setText(sb.toString());
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        TXTPALABRA1 = new javax.swing.JTextField();
        TXTPALABRA2 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TEXTAREA = new javax.swing.JTextArea();
        BTNCOMPARAR = new javax.swing.JButton();
        CMBCATEGORIA = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        LISTPALABRAS = new javax.swing.JList<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("EDICION DE PALABRAS POR CATEGORIA");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("COMPARACION DE PALABRAS");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("PALABRA 1:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("PALABRA 2: ");

        TEXTAREA.setColumns(20);
        TEXTAREA.setRows(5);
        jScrollPane1.setViewportView(TEXTAREA);

        BTNCOMPARAR.setBackground(new java.awt.Color(204, 255, 204));
        BTNCOMPARAR.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BTNCOMPARAR.setText("COMPARAR");
        BTNCOMPARAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNCOMPARARActionPerformed(evt);
            }
        });

        CMBCATEGORIA.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        CMBCATEGORIA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        LISTPALABRAS.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(LISTPALABRAS);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("CATEGORIA");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("LISTA DE PALABRA");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(CMBCATEGORIA, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(TXTPALABRA1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(jLabel4)
                                .addGap(33, 33, 33)
                                .addComponent(TXTPALABRA2, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(240, 240, 240)
                        .addComponent(BTNCOMPARAR)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(TXTPALABRA1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TXTPALABRA2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(BTNCOMPARAR)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(12, 12, 12)
                                .addComponent(CMBCATEGORIA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTNCOMPARARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNCOMPARARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BTNCOMPARARActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNCOMPARAR;
    private javax.swing.JComboBox<String> CMBCATEGORIA;
    private javax.swing.JList<String> LISTPALABRAS;
    private javax.swing.JTextArea TEXTAREA;
    private javax.swing.JTextField TXTPALABRA1;
    private javax.swing.JTextField TXTPALABRA2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
