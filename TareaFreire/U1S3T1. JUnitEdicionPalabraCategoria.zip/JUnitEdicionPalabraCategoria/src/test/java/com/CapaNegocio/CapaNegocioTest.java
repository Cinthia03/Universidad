
package com.CapaNegocio;

import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class CapaNegocioTest {
    
    private CapaNegocio negocio;

    @BeforeEach
    public void setUp() {
        negocio = new CapaNegocio();
    }

    @Test
    public void editarPalabraCorrecto() {
        boolean resultado = negocio.editarPalabra("Animales", 1, "Lobo");
        List<String> palabras = negocio.obtenerPalabrasPorCategoria("Animales");
        assertTrue(resultado, "La palabra debe actualizarse correctamente");
        assertEquals("Lobo", palabras.get(1), "La palabra en la posición debe ser 'Lobo'");
    }

    @Test
    public void editarPalabraIguaDuplicada() {
        boolean resultado = negocio.editarPalabra("Animales", 1, "Gato");
        assertFalse(resultado, "No debe actualizar si la palabra es igual o duplicada");
    }


    @Test
    public void editarPalabraCategoriaInexistente() {
        boolean resultado = negocio.editarPalabra("Inexistente", 0, "Violeta");
        assertFalse(resultado, "No debe actualizar si la categoría no existe");
    }

    
    @Test
    public void editarPalabraCampoVacio() {
        boolean resultado = negocio.editarPalabra("Colores", 4, "");
        assertFalse(resultado, "No debe actualizar con nombre vacío");
    }
    
    
    

    @Test
    public void editarPalabraMismaPalabra() {
        boolean resultado = negocio.editarPalabra("Animales", 1, "Gato");
        assertTrue(resultado, "Este test debe fallar porque la palabra es igual y no se debería actualizar");
    }
}