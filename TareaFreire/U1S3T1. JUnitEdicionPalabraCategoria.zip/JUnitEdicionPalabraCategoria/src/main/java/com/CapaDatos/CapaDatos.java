package com.CapaDatos;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.*;

public class CapaDatos {
    private static Map<String, List<String>> categorias = new HashMap<>();
    private static List<String> Palabra1 = new ArrayList<>();
    private static List<String> Palabra2 = new ArrayList<>();
    private static List<String> resultadosComparacion = new ArrayList<>();

    static {
        categorias.put("Animales", new ArrayList<>(Arrays.asList("Perro", "Gato", "León")));
        categorias.put("Colores", new ArrayList<>(Arrays.asList("Rojo", "Azul", "Verde")));
        categorias.put("Utensilios", new ArrayList<>(Arrays.asList("Cuchara", "Tenedor", "Cuchillo")));
    }

    public static Set<String> obtenerCategorias() {
        return categorias.keySet();
    }

    public static List<String> obtenerPalabrasPorCategoria(String categoria) {
        return categorias.getOrDefault(categoria, new ArrayList<>());
    }

    public static boolean editarPalabra(String categoria, int indice, String nuevaPalabra) {
        if (categoria == null || nuevaPalabra == null || nuevaPalabra.isEmpty()) {
            return false;
        }
        List<String> palabras = categorias.get(categoria);
        if (palabras == null || indice < 0 || indice >= palabras.size()) {
            return false;
        }
        String palabraActual = palabras.get(indice);
        if (palabraActual.equalsIgnoreCase(nuevaPalabra)) {
            return false; // No actualizar si es la misma palabra
        }
        for (int i = 0; i < palabras.size(); i++) {
            if (i != indice && palabras.get(i).equalsIgnoreCase(nuevaPalabra)) {
                return false; // No actualizar si ya existe la palabra en la categoría
            }
        }
        palabras.set(indice, nuevaPalabra);
        categorias.put(categoria, palabras);
        return true;
    }
    
    public static void agregarPalabraACategoria(String categoria, String palabra) {
        List<String> palabras = categorias.getOrDefault(categoria, new ArrayList<>());
        if (!palabras.contains(palabra)) {
            palabras.add(palabra);
            categorias.put(categoria, palabras);
        }
    }

    
    
    
    //COMPARACION DE PALABRAS
    public static void guardarComparacion(String p1, String p2, String resultado) {
        Palabra1.add(p1);
        Palabra2.add(p2);
        resultadosComparacion.add(resultado);
    }

    public static List<String> getListaPalabra1() { return Palabra1; }
    public static List<String> getListaPalabra2() { return Palabra2; }
    public static List<String> getResultadosComparacion() { return resultadosComparacion; }
}