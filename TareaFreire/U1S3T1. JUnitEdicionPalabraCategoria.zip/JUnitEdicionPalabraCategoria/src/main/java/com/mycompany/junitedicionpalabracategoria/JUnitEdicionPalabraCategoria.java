
package com.mycompany.junitedicionpalabracategoria;

import javax.swing.SwingUtilities;
//import com.CapaInterfaz.ComparacionPalabras;
import com.CapaInterfaz.EdicionPalabraCategoria;
import com.CapaInterfaz.IMessageHandler;
import com.CapaInterfaz.JOptionPaneMessageHandler;
import com.CapaNegocio.CapaNegocio;


public class JUnitEdicionPalabraCategoria {

    public static void main(String[] args) {
        CapaNegocio negocio = new CapaNegocio();
        SwingUtilities.invokeLater(() -> {
            IMessageHandler handler = new JOptionPaneMessageHandler();
            EdicionPalabraCategoria editor = new EdicionPalabraCategoria(negocio, handler);
            editor.setVisible(true);
            //ComparacionPalabras comparador = new ComparacionPalabras(negocio, handler);
            //comparador.setVisible(true);
        });
    }
}
