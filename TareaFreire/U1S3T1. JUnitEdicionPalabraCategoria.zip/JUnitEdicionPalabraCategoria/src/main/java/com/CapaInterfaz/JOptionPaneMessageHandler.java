package com.CapaInterfaz;

import com.CapaInterfaz.IMessageHandler;
import javax.swing.JOptionPane;

public class JOptionPaneMessageHandler implements IMessageHandler {
    @Override
    public void showMessage(String message, String title, int messageType) {
        JOptionPane.showMessageDialog(null, message, title, messageType);
    }
}
