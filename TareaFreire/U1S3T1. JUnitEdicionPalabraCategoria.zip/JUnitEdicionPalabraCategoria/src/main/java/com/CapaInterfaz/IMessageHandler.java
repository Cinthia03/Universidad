
package com.CapaInterfaz;

public interface IMessageHandler {
        void showMessage(String message, String title, int messageType);
}
