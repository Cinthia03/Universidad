package com.CapaNegocio;

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class CapaNegocioAssertionsTest {
    
    private CapaNegocio negocio;

    @BeforeEach
    public void setUp() {
        negocio = new CapaNegocio(); // Usa datos quemados con categorías y palabras
    }

    @Test
    public void testAssertTrueEditarPalabra() {
        assertTrue(negocio.editarPalabra("Animales", 0, "Lobo"),
                   "Debe actualizar la palabra correctamente (verdadero)");
    }

    @Test
    public void testAssertFalseEditarPalabra() {
        // Intentar actualizar con la palabra igual - debe retornar false
        assertFalse(negocio.editarPalabra("Animales", 1, "Gato"),
                    "No debe actualizar palabra misma (falso)");
    }

    @Test
    public void testAssertNullObtenerCategoriaInexistente() {
        // No existe categoría "NoExiste", lista debe ser null o vacía
        List<String> lista = negocio.obtenerPalabrasPorCategoria("NoExiste");
        assertTrue(lista == null || lista.isEmpty(),
                   "Lista debe ser null o vacía si la categoría no existe");
    }

    @Test
    public void testAssertNotNullObtenerPalabras() {
        List<String> lista = negocio.obtenerPalabrasPorCategoria("Colores");
        assertNotNull(lista, "Lista no debe ser null para categoría existente");
    }

    @Test
    public void testAssertEqualsPalabraEditada() {
        negocio.editarPalabra("Animales", 1, "Lobo");
        List<String> lista = negocio.obtenerPalabrasPorCategoria("Animales");
        assertEquals("Lobo", lista.get(1), "Palabra debe ser actualizada a Lobo");
    }

    @Test
    public void testAssertNotEqualsPalabraNoEditada() {
        negocio.editarPalabra("Colores", 0, "Rojo");
        List<String> lista = negocio.obtenerPalabrasPorCategoria("Colores");
        assertNotEquals("Azul", lista.get(0), "La palabra no debe cambiar a Azul");
    }

    @Test
    public void testAssertSameObjetoLista() {
        List<String> l1 = negocio.obtenerPalabrasPorCategoria("Utensilios");
        List<String> l2 = negocio.obtenerPalabrasPorCategoria("Utensilios");
        assertSame(l1, l2, "Ambas listas de la categoría Utensilios deberían ser la misma referencia");
    }

    @Test
    public void testAssertNotSameListaDiferenteCategorias() {
        List<String> l1 = negocio.obtenerPalabrasPorCategoria("Animales");
        List<String> l2 = negocio.obtenerPalabrasPorCategoria("Colores");
        assertNotSame(l1, l2, "Listas de categorías diferentes no deben ser la misma referencia");
    }

    @Test
    public void testAssertArrayEqualsPalabras() {
        String[] esperado = {"Perro", "Gato", "León"};
        List<String> lista = negocio.obtenerPalabrasPorCategoria("Animales");
        assertArrayEquals(esperado, lista.toArray(new String[0]), "Las palabras deben coincidir");
    }

    @Test
    public void testAssertThrowsEditarPalabraNullCategoria() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            negocio.editarPalabra(null, 0, "Lobo");
        });
        // Puedes probar mensaje u otro detalle si aplica
        assertNotNull(exception, "Se debe lanzar NullPointerException si categoria es null");
    }
}