
package busquedalindao.controlador;

import busquedalindao.datos.UsuarioDatos;
import busquedalindao.modelo.Usuario;
import java.util.List;

/**
 * @author HP
 */
public class UsuarioControlador {
     private UsuarioDatos dao;

    public UsuarioControlador() {
        dao = new UsuarioDatos();
    }

    public void guardarUsuario(String nombre, String apellido, String correo, String celular) {
        Usuario u = new Usuario(nombre, apellido, correo, celular);
        dao.agregarUsuario(u);
    }

    public List<Usuario> obtenerUsuarios() {
        return dao.listarUsuarios();
    }

    public Usuario buscarUsuario(String nombre) {
        return dao.buscarPorNombre(nombre);
    }
}
