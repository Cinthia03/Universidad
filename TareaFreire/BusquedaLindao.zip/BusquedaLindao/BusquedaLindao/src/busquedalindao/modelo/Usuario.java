
package busquedalindao.modelo;

/**
 *
 * @author HP
 */
public class Usuario {
     private String nombre;
    private String apellido;
    private String correo;
    private String celular;

    public Usuario(String nombre, String apellido, String correo, String celular) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.celular = celular;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getCelular() { return celular; }
    public void setCelular(String celular) { this.celular = celular; }
}
