
package busquedalindao.datos;

import busquedalindao.modelo.Usuario;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HP
 */
public class UsuarioDatos {
    private List<Usuario> listaUsuarios = new ArrayList<>();

    public void agregarUsuario(Usuario usuario) {
        listaUsuarios.add(usuario);
    }

    public List<Usuario> listarUsuarios() {
        return listaUsuarios;
    }

    public Usuario buscarPorNombre(String nombre) {
        for (Usuario u : listaUsuarios) {
            if (u.getNombre().equalsIgnoreCase(nombre)) {
                return u;
            }
        }
        return null;
    }
}
