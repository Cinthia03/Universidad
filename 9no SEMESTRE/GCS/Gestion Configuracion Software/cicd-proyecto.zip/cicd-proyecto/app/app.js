let flowers = [
  { name: "Rosas", stock: 120, price: 1.50 },
  { name: "Tulipanes", stock: 80, price: 2.00 },
  { name: "Orquídeas", stock: 45, price: 3.75 },
  { name: "Petunias", stock: 100, price: 2.00 }
];

let filteredFlowers = flowers;

const tableBody = document.getElementById("table-body");
const salesTable = document.getElementById("sales-table");
const form = document.getElementById("flower-form");
const editIndexInput = document.getElementById("editIndex");

/* LOGIN */
function login() {
  const user = document.getElementById("user").value;
  const pass = document.getElementById("password").value;
  const error = document.getElementById("login-error");

  if (user === "admin" && pass === "1234") {
    document.getElementById("login-container").style.display = "none";
    document.getElementById("app").style.display = "block";
    renderAll();
  } else {
    error.textContent = "Usuario o contraseña incorrecta";
  }
}

/* PESTAÑAS */
function showTab(tab) {
  document.getElementById("inventario").style.display = "none";
  document.getElementById("ventas").style.display = "none";
  document.getElementById(tab).style.display = "block";
}

/* RENDER GENERAL */
function renderAll() {
  renderInventory();
  filteredFlowers = flowers;
  renderSales(filteredFlowers);
}

/* INVENTARIO */
function renderInventory() {
  tableBody.innerHTML = "";
  flowers.forEach((f, i) => {
    tableBody.innerHTML += `
      <tr>
        <td>${f.name}</td>
        <td>${f.stock}</td>
        <td>$${f.price.toFixed(2)}</td>
        <td>
          <button class="action-btn edit" onclick="editFlower(${i})">Editar</button>
          <button class="action-btn delete" onclick="deleteFlower(${i})">Eliminar</button>
        </td>
      </tr>
    `;
  });
}

form.addEventListener("submit", e => {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const stock = parseInt(document.getElementById("stock").value);
  const price = parseFloat(document.getElementById("price").value);
  const index = editIndexInput.value;

  if (index === "") {
    flowers.push({ name, stock, price });
  } else {
    flowers[index] = { name, stock, price };
  }

  resetForm();
  renderAll();
});

function editFlower(i) {
  document.getElementById("name").value = flowers[i].name;
  document.getElementById("stock").value = flowers[i].stock;
  document.getElementById("price").value = flowers[i].price;
  editIndexInput.value = i;
}

function deleteFlower(i) {
  if (confirm("¿Eliminar flor del inventario?")) {
    flowers.splice(i, 1);
    renderAll();
  }
}

function resetForm() {
  form.reset();
  editIndexInput.value = "";
}

/* VENTAS */
function renderSales(list) {
  salesTable.innerHTML = "";
  const qty = parseInt(document.getElementById("global-qty").value) || 0;

  list.forEach(f => {
    const index = flowers.indexOf(f);
    const total = qty > 0 ? (qty * f.price).toFixed(2) : "0.00";

    salesTable.innerHTML += `
      <tr>
        <td>${f.name}</td>
        <td>$${f.price.toFixed(2)}</td>
        <td>${f.stock}</td>
        <td>
          <button onclick="sellFlower(${index})">Vender</button>
        </td>
        <td>$${total}</td>
      </tr>
    `;
  });
}

function sellFlower(index) {
  const qty = parseInt(document.getElementById("global-qty").value);

  if (!qty || qty <= 0) {
    alert("Ingrese una cantidad válida");
    return;
  }

  if (flowers[index].stock >= qty) {
    flowers[index].stock -= qty;
    alert(`🌸 Venta realizada: ${qty} ${flowers[index].name}`);
    renderInventory();
    renderSales(filteredFlowers);
  } else {
    alert("❌ Stock insuficiente");
  }
}

/* FILTRO */
function filterFlowers() {
  const text = document.getElementById("search").value.toLowerCase();

  filteredFlowers = flowers.filter(f =>
    f.name.toLowerCase().startsWith(text)
  );

  renderSales(filteredFlowers);
}

/* CANTIDAD */
function updateTotals() {
  renderSales(filteredFlowers);
}
