package com.mycompany.cinthiatenesacap5;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Cinth
 */
public class CinthiaTenesacaP5 {

    public static void main(String[] args) {
        Rango r1 = new Rango("Primer Rango", 2020, 2025);
        Rango r2 = new Rango("Segundo Rango", 2000, 2020);
        
        r1.verificar();
        r2.verificar();
    }
}
    
    class Rango{
        String nombre;
        int inicio;
        int fin;
        List<Integer> Bisiesto;

        public Rango(String nombre, int inicio, int fin) {
            this.nombre = nombre;
            this.inicio = inicio;
            this.fin = fin;
            this.Bisiesto = new ArrayList<>();
        }
        
        public void verificar(){
            for (int anio = inicio; anio <= fin; anio++) {

            try {
                verificarAnio(anio);
            } catch (NoBisiestoException e) {
                System.out.println(e.getMessage());
            }
        }
        mostrarBisiestos();
        }
        
        private void verificarAnio(int anio) throws NoBisiestoException {
            if (Bisiesto(anio)) {
                Bisiesto.add(anio);
            } else {
                throw new NoBisiestoException(anio, nombre);
            }
        }
        
        private void mostrarBisiestos() {
            System.out.println("Anios bisiestos encontrados en " + nombre + ":");

            if (Bisiesto.isEmpty()) {
                System.out.println("No se encontraron anios bisiestos.");
            } else {
                for (int anio : Bisiesto) {
                    System.out.println("Anio bisiesto: " + anio);
                }
            }
        }
        
        private boolean Bisiesto(int anio){
            if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0)) {
            return true;
        }
            return false;
        }     
    }    

class NoBisiestoException extends Exception {

    public NoBisiestoException(int anio, String rango) {
        super("El anio " + anio + " no es bisiesto en el " + rango);
    }
}
