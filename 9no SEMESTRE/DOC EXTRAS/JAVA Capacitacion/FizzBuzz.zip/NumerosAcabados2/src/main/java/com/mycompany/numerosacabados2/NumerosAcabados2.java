package com.mycompany.numerosacabados2;
import java.util.Scanner;
/**
 *
 * @author Cinth
 */
public class NumerosAcabados2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero, termino2=0, impares=0;
        
        System.out.print("Introduce los numeros: ");
        
        while (true){  
            numero = sc.nextInt();
            
            if(numero < 0){
                break;
            }
            
            if(numero % 10 == 2){
                termino2++;
            }
            
            if(numero % 2 != 0){
                impares++;
            }
        }
        
        System.out.println("Numeros teminados en 2: " +termino2);
        System.out.println("Numeros impares: " +impares);
        
        sc.close();
    }
}
