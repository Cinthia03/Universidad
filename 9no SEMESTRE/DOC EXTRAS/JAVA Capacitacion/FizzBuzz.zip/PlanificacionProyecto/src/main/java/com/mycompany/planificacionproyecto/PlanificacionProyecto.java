package com.mycompany.planificacionproyecto;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author Cinth
 */
public class PlanificacionProyecto {
    public static void main(String[] args) {
        System.out.println("PLANIFICACION DE PROYECTO EMPRESA XYZ");
    
        LocalDate fechaInicio = LocalDate.of(2026,4,5);
        LocalDate fechaFin = LocalDate.of(2026,10,12);
        LocalDate fechaActual = LocalDate.now();
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        
        System.out.println("Fecha Inicio: " +fechaInicio.format(formatter));
        System.out.println("Fecha Fin: " +fechaFin.format(formatter));
        System.out.println("Fecha Actual: " +fechaActual.format(formatter));
        
        
        //COMPARACION SI YA COMENZO O FINALIZO
        if(fechaActual.isBefore(fechaInicio)){
            System.out.println("Proyecto no ha iniciado"); 
        }else if(fechaActual.isAfter(fechaFin)){
            System.out.println("Proyecto ya finalizo");     
        }else{
            System.out.println("Proyecto en ejecucion");            
        }
        
        
        //CALCULAR DIAS RESTANTES
        long days = ChronoUnit.DAYS.between(fechaActual, fechaFin);
        if(days>0){
            System.out.println("Dias faltantes para la entrega: " +days);
        }else{
            System.out.println("La fecha de entrega ya paso");         
        }        
    }
}
