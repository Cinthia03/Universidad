package com.mycompany.palindromo;

import java.util.Scanner;

/**
 *
 * @author Cinth
 */
public class Palindromo {
    
    public static boolean validar(String palabra){
        for(int i=0, j=palabra.length()-1; i < j; i++, j--) {
           if (palabra.charAt(i) != palabra.charAt(j)) {
               return false;
           }
       }
       return true;
   }      
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String palabra;
        
        System.out.print("Introduce la palabra: ");
        palabra = sc.nextLine();
                
        if(validar(palabra)){
            System.out.println("La palabra: " +palabra+ " es palindromo");
        }else{
            System.out.println("La palabra: " +palabra+ " no es palindromo");
        }
        
        System.out.println("La cantidad de caracteres son: " +palabra.length());
        sc.close();
    }
}
