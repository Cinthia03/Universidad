package com.mycompany.cinthiatenesacap2;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Scanner;

/**
 *
 * @author Cinth
 */
public class CinthiaTenesacaP2 {
    
    static class Producto {
        private double precio;
        private String nombre;

        public Producto(double precio, String nombre) {
            this.precio = precio;
            this.nombre = nombre;
        }

        public double getPrecio() {
            return precio;
        }

        public void setPrecio(double precio) {
            this.precio = precio;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        @Override
        public String toString() {
            return "Nombre: " + nombre + " - Precio: $" +precio;
        }
    }
    
    static class Carrito{
        private final List<Producto> productos = new ArrayList<>();
        
        public void agregarProducto(Producto producto) {
            productos.add(producto);
        }

        public Optional<Producto> buscarProducto(String nombre) {
            for (Producto p : productos) {
                if (p.getNombre().equalsIgnoreCase(nombre)) {
                    return Optional.of(p);
                }
            }
            return Optional.empty();
        }

        public boolean eliminarProducto(String nombre) {
            Optional<Producto> producto = buscarProducto(nombre);
            if (producto.isPresent()) {
                productos.remove(producto.get());
                return true;
            }
            return false;
        }

        public void mostrarCarrito() {
            if (productos.isEmpty()) {
                System.out.println("El carrito esta vacio.");
            } else {
                double total = 0;
                System.out.println("Productos en el carrito:");
                for (Producto p : productos) {
                    System.out.println(p);
                    total += p.getPrecio();
                }
                System.out.println("Total a pagar: $" + String.format(Locale.US, "%.2f", total));
            }
        }
    }
    

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        int seleccion;
        Carrito carrito = new Carrito();
        
        while(!salir){
           System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~ MENU ~~~~~~~~~~~~~~~~~~~~~~~~~"); 
           System.out.println("1. AGREGAR PRODUCTOS AL CARRITO");
           System.out.println("2. MOSTRAR PRODUCTOS ACTUALES EN EL CARRITO JUNTO COSTO TOTAL");
           System.out.println("3. ELIMINAR UN PRODUCTO DEL CARRITO INGRESANDO NOMBRE");
           System.out.println("4. IMPRIMIR LISTADO FINAL");
           System.out.println("5. Salir");
           
           System.out.print("Escribe una de las opciones: ");
           seleccion = sc.nextInt();  
           
           switch(seleccion){
                case 1 -> {
                    System.out.println("******************************AGREGAR PRODUCTO******************************");
                    System.out.print("Ingrese nombre del producto: ");
                    String nombre = sc.next();
                    System.out.print("Ingrese precio del producto: ");
                    Double precio = sc.nextDouble();
                    
                    carrito.agregarProducto(new Producto(precio, nombre));
                    System.out.println("Producto agregado con exito");
                }
                case 2 -> {
                    System.out.println("******************************MOSTRAR PRODUCTOS ACTUALES******************************");
                    carrito.mostrarCarrito();
                }
                case 3 -> {
                    System.out.println("******************************ELIMINAR UN PRODUCTO******************************");
                    System.out.print("Ingrese nombre del producto: ");
                    String nombre = sc.next();
                    if(carrito.eliminarProducto(nombre)){
                        System.out.println("Eliminado correctamente");
                    }else{
                        System.out.println("No se encontro el producto a eliminar");
                    }
                }
                case 4 -> {
                    System.out.println("******************************IMPRIMIR LISTADO FINAL******************************");
                    System.out.println("Resumen Final");
                    carrito.mostrarCarrito();
                }
                case 5 -> salir=true;
                default -> System.out.println("Solo números entre 1 y 5");
           }
       }
    }
}

