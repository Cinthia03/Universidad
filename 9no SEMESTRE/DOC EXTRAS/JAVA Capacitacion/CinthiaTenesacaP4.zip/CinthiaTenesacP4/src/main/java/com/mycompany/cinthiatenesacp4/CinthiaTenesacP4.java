package com.mycompany.cinthiatenesacp4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

/**
 *
 * @author Cinth
 */
public class CinthiaTenesacP4 {
    
    static class Productos {
        String nombreProducto;
        int codigoProducto;
        int cantidadStock;
        double precio;
        String categoria;

        public Productos(String nombreProducto, int codigoProducto, int cantidadStock, double precio, String categoria) {
            this.nombreProducto = nombreProducto;
            this.codigoProducto = codigoProducto;
            this.cantidadStock = cantidadStock;
            this.precio = precio;
            this.categoria = categoria;
        }

        public String getNombreProducto() {
            return nombreProducto;
        }

        public void setNombreProducto(String nombreProducto) {
            this.nombreProducto = nombreProducto;
        }

        public int getCodigoProducto() {
            return codigoProducto;
        }

        public void setCodigoProducto(int codigoProducto) {
            this.codigoProducto = codigoProducto;
        }

        public int getCantidadStock() {
            return cantidadStock;
        }

        public void setCantidadStock(int cantidadStock) {
            this.cantidadStock = cantidadStock;
        }

        public double getPrecio() {
            return precio;
        }

        public void setPrecio(double precio) {
            this.precio = precio;
        }

        public String getCategoria() {
            return categoria;
        }

        public void setCategoria(String categoria) {
            this.categoria = categoria;
        }

        @Override
        public String toString() {
            return "Nombre: " +nombreProducto+ " - Codigo: " +codigoProducto+ " - Cantidad: " +cantidadStock+ 
                    " - Precio: " +precio+ " - Categoria: " +categoria;
        }    
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        int seleccion;
        
        //LIST
        List <Productos> productos = new ArrayList<>();
        productos.add(new Productos("Arroz", 101, 50, 1.25, "Alimentos"));
        productos.add(new Productos("Leche", 102, 30, 0.95, "Lacteos"));
        productos.add(new Productos("Pan", 103, 40, 0.50, "Panaderia"));
        productos.add(new Productos("Jabon", 104, 25, 1.75, "Higiene"));
        productos.add(new Productos("Gaseosa", 105, 20, 1.50, "Bebidas"));
        productos.add(new Productos("Queso", 102, 30, 0.95, "Lacteos"));
        
        //SET
        Set <String> categorias = new HashSet<>();
            for(Productos p : productos){
                categorias.add(p.getCategoria());
            }
        
        //MAP
        Map <String, Integer> ventas = new HashMap<>();
        ventas.put("Arroz", 10);
        ventas.put("Leche", 5);
        ventas.put("Pan", 1);
        ventas.put("Jabon", 4);
        ventas.put("Gaseosa", 10);
        
        while(!salir){
           System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~ MENU ~~~~~~~~~~~~~~~~~~~~~~~~~"); 
           System.out.println("1. LISTAR PRODUCTOS POR CATEGORIA");
           System.out.println("2. TOTAL DE PRODUCTOS VENDIDOS EN UN DIA");
           System.out.println("3. INFORME DE PRODUCTOS MAS VENDIDOS ORDEN DESCENDENTE");
           System.out.println("4. CALCULAR TOTAL DE GANANCIA");
           System.out.println("5. BUSCAR PRODUCTO POR RANGO DE PRECIO");
           System.out.println("6. SALIR");
           
           System.out.print("Escribe una de las opciones: ");
           seleccion = sc.nextInt();  
           
           switch(seleccion){
                case 1 -> {
                    System.out.println("******************************LISTAR PRODUCTOS POR CATEGORIA******************************");
                    System.out.print("Ingrese Categoria: ");
                    String categoria = sc.next();  
                        productos.stream()
                                .filter(p -> p.getCategoria().equalsIgnoreCase(categoria))
                                .forEach(System.out::println);
                        break;
                }
                case 2 -> {
                    System.out.println("******************************TOTAL DE PRODUCTOS VENDIDOS EN UN DIA******************************");
                    int totalVendidos = ventas.values()
                            .stream()
                            .mapToInt(Integer::intValue)
                            .sum();
                    System.out.println("Total vendidos hoy: " + totalVendidos);
                    break;
                }
                case 3 -> {
                    System.out.println("******************************INFORME DE PRODUCTOS MAS VENDIDOS ORDEN DESCENDENTE******************************");
                    List<Map.Entry<String, Integer>> ranking = ventas.entrySet()
                            .stream()
                            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                            .collect(Collectors.toList());

                    int posicion = 1;

                    for (Map.Entry<String, Integer> entry : ranking) {
                        System.out.println(posicion + ". " + entry.getKey()
                                + " | Cantidad vendida: " + entry.getValue());
                        posicion++;
                    }
                    break;
                }
                case 4 -> {
                    System.out.println("******************************CALCULAR TOTAL DE GANANCIA******************************");
                    double ganancias = ventas.entrySet()
                            .stream()
                            .mapToDouble(e -> {
                                Optional<Productos> prod = productos.stream()
                                        .filter(p -> p.getNombreProducto().equals(e.getKey()))
                                        .findFirst();
                                return prod.map(producto -> producto.getPrecio() * e.getValue()).orElse(0.0);
                            }).sum();

                    double totalMes = ganancias * 30;
                    System.out.println("Ganancias estimadas del dia: $" + ganancias);
                    System.out.println("Ganancias estimadas del mes: $" + totalMes);
                    break;
                }
                case 5 -> {
                    System.out.println("******************************BUSCAR PRODUCTO POR RANGO DE PRECIO******************************");
                    System.out.print("Precio minimo: ");
                    double min = sc.nextDouble();
                    System.out.print("Precio maximo: ");
                    double max = sc.nextDouble();
                    System.out.println("Productos encontrados: ");
                        productos.stream()
                            .filter(p -> p.getPrecio() >= min && p.getPrecio() <= max)
                            .forEach(System.out::println);
                    break;
                }
                case 6 -> salir=true;
                default -> System.out.println("Solo números entre 1 y 5");
           }
       }
    }
}
