package com.mycompany.cinthiatenesacap1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Cinth
 */
public class CinthiaTenesacaP1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        int seleccion;
        int millas, numero, horas, conv, n1, n2, suma=0, num, decimal, radio;
        double conversion, promedio, pi=3.1416, area;
        String palabra, binario; 
        
        while(!salir){
           System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~ MENU ~~~~~~~~~~~~~~~~~~~~~~~~~"); 
           System.out.println("1. Conversion Millas a Km");
           System.out.println("2. Numero Primo");
           System.out.println("3. Calculo Factorial");
           System.out.println("4. Tabla Multiplicar");
           System.out.println("5. Conteo Vocales");
           System.out.println("6. Conversion Horas a Segundos");
           System.out.println("7. Suma de Digitos");
           System.out.println("8. Generador Numeros Aleatorios");
           System.out.println("9. Conversion Binario a Decimal");
           System.out.println("10. Calcular Area de un circulo");
           System.out.println("11. Salir");
           
           System.out.print("Escribe una de las opciones: ");
           seleccion = sc.nextInt();  
           
           switch(seleccion){
                case 1:
                   System.out.println("******************************CONVERSION MILLAS A KM******************************");
                    System.out.print("Ingresa Millas: ");
                    millas = sc.nextInt();
                    conversion = millas * 1.60934;
                    System.out.println("La conversion de millas a km es: " +conversion);
                    break;
                case 2:
                   System.out.println("******************************NUMERO PRIMO******************************"); 
                   boolean primo = false;
                   System.out.print("Introduce el numero: ");
                   numero = sc.nextInt();
                    if(numero == 0 || numero == 1){
                        primo = true;
                    }
                    for(int i=2; i<numero; i++){
                        if(numero % i == 0){
                            primo = true;
                            break;
                        }
                    }
                    if(!primo){
                        System.out.println("El numero: " +numero+ " es primo");
                    }else{
                        System.out.println("El numero: " +numero+ " no es primo");
                    }    
                   break;
                case 3:
                   System.out.println("******************************CALCULO FACTORIAL******************************");
                   int factorial=1;
                   System.out.print("Introduce el numero: ");
                   numero = sc.nextInt();
                     for(int i=1; i<=numero; i++){
                        factorial = factorial * i;
                     }
                   System.out.println("El factorial del numero: " +numero+ " es: " +factorial);
                   break;
                case 4:
                   System.out.println("******************************TABLA DE MULTIPLICAR******************************");
                   System.out.print("Introduce el numero: ");
                   numero = sc.nextInt();
                    System.out.println("Tabla del " + numero);
                    for(int i = 1; i<=10; i++){
                        System.out.println(numero + " * " + i + " = " + numero*i);                                                     
                    }                   
                   break;
                case 5:
                   System.out.println("******************************CONTEO DE VOCALES******************************");
                   int contador = 0;
                   System.out.print("Introduce la palabra: ");
                   palabra = sc.next();
                     for (char c : palabra.toLowerCase().toCharArray()) {
                        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                          contador++;
                        }
                     }
                   System.out.println("La palabra " +palabra+ " tiene " +contador+  " vocales ");
                   break;
                case 6:
                   System.out.println("******************************CONVERSION HORAS A SEGUNDOS******************************");
                    System.out.print("Ingresa Horas: ");
                    horas = sc.nextInt();
                    conv = horas * 3600;
                    System.out.println("La conversion de horas a segundos es: " +conv);
                    break;
                case 7:
                   System.out.println("******************************SUMA DE DIGITOS******************************");
                    System.out.print("Ingresa numero: ");
                    n1 = sc.nextInt(); 
                    System.out.print("Ingresa numero: ");
                    n2 = sc.nextInt(); 
                    suma = n1+n2;
                    System.out.println("La suma de los digitos ingresados es: " +suma);
                    break;
                case 8:
                   System.out.println("******************************NUMEROS ALEATORIOS******************************");
                    Random r = new Random();
                    System.out.print("Ingresa cantidad de numero: ");
                    numero = sc.nextInt(); 
                        for(int i=1; i<=numero; i++){
                            num = r.nextInt(100);
                            System.out.println("Numero aleatorio: " +i+ ": " +num);
                            suma = suma + num;
                        }
                    promedio = (double)suma/numero;
                    System.out.println("La suma es: " +suma);
                    System.out.println("El promedio es: " +promedio);
                   break;
                case 9:
                   System.out.println("******************************CONVERSION BINARIO A DECIMAL******************************");
                    System.out.print("Ingresa cantidad binaria: ");
                    binario = sc.next();
                    decimal = Integer.parseInt(binario,2);  
                    System.out.println("La conversion de binario a decimal es: " +decimal);
                    break;
                case 10:
                   System.out.println("******************************CALCULO AREA DE CIRCULO******************************");
                    System.out.print("Ingresa el radio: ");
                    radio = sc.nextInt(); 
                    area = pi*(radio*radio);
                    System.out.println("El area del circulo es: " +area+"cm al cuadrado");
                    break;
                case 11:
                   salir=true;
                   break;
                default:
                   System.out.println("Solo números entre 1 y 11");
           }
       }
    }
}
