package com.mycompany.cinthiatenesacap3;

import java.util.Scanner;

/**
 *
 * @author Cinth
 */
public class CinthiaTenesacaP3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        int seleccion;
        Vehiculo vehiculo = null;
        
        
        while(!salir){
           System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~ MENU ~~~~~~~~~~~~~~~~~~~~~~~~~"); 
           System.out.println("1. CREAR AUTOMOVIL");
           System.out.println("2. CREAR MOTOCICLETA");
           System.out.println("3. MOVER VEHICULO");
           System.out.println("4. CALCULAR VELOCIDAD MAXIMA");
           System.out.println("5. CALCULAR COSTO DE MANTENIMIENTO");
           System.out.println("6. SALIR");
           
           System.out.print("Escribe una de las opciones: ");
           seleccion = sc.nextInt();  
           
           switch(seleccion){
                case 1 -> {
                    System.out.println("******************************CREAR AUTOMOVIL******************************");
                    System.out.print("Ingresar Marca: ");
                    String Marca = sc.next(); 
                    System.out.print("Ingresar Modelo: ");
                    String Modelo = sc.next(); 
                    System.out.print("Ingresar Año: ");
                    int Anio = sc.nextInt(); 
                    System.out.print("Ingresar Tipo de combustible: ");
                    String Combustible = sc.next(); 
                    System.out.print("Ingresar Placa: ");
                    String Placa = sc.next(); 
                    System.out.print("Ingresar Cilindraje: ");
                    Double Cilindraje = sc.nextDouble(); 
                    System.out.print("Ingresar color: "); 
                    String color = sc.next(); 
                    System.out.print("Ingresar Numeros de Puertas: ");
                    int numeroPuertas = sc.nextInt(); 
                    
                    vehiculo = new Automovil (color, numeroPuertas, Marca, Modelo, Anio, Combustible, Placa, Cilindraje);
                    System.out.println("Automovil ingresado con exito");
                    break;
                }
                case 2 -> {
                    System.out.println("******************************CREAR MOTOCICLETA******************************");
                    System.out.print("Ingresar Marca: ");
                    String Marca = sc.next(); 
                    System.out.print("Ingresar Modelo: ");
                    String Modelo = sc.next(); 
                    System.out.print("Ingresar Año: ");
                    int Anio = sc.nextInt(); 
                    System.out.print("Ingresar Tipo de combustible: ");
                    String Combustible = sc.next(); 
                    System.out.print("Ingresar Placa: ");
                    String Placa = sc.next(); 
                    System.out.print("Ingresar Cilindraje: ");
                    Double Cilindraje = sc.nextDouble(); 
                    System.out.print("Ingresar Tipo: ");
                    String tipo = sc.next(); 
                    
                    vehiculo = new Motocicleta (tipo, Marca, Modelo, Anio, Combustible, Placa, Cilindraje);
                    System.out.println("Automovil ingresado con exito");
                    break;
                }
                case 3 -> {
                    System.out.println("******************************MOVER VEHICULO******************************");
                    if(vehiculo != null){
                        System.out.print("Distancia a mover: ");
                        double distancia = sc.nextDouble();
                        System.out.println(vehiculo.mover(distancia));
                    } else {
                        System.out.println("Primero cree un vehiculo");
                    }
                    break;
                }
                case 4 -> {
                    System.out.println("******************************CALCULAR VELOCIDAD MAXIMA******************************");
                    if(vehiculo != null){
                        System.out.println("Velocidad Maxima: " +vehiculo.calcularVelocidadMaxima()+ " Km/h");
                    }else{
                        System.out.println("Primero cree el vehiculo");
                    }
                }
                case 5 -> {
                    System.out.println("******************************CALCULAR COSTO DE MANTENIMIENTO******************************");
                    if(vehiculo != null){
                        System.out.println("Costo de mantenimiento: $" +vehiculo.calcularCostoMantenimiento());
                    }else{
                        System.out.println("Primero cree el vehiculo");
                    }
                }
                case 6 -> salir=true;
                default -> System.out.println("Solo números entre 1 y 5");
           }
       }
    }
}
