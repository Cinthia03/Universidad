package com.mycompany.cinthiatenesacap3;

/**
 *
 * @author Cinth
 */
public abstract class Vehiculo implements IntMover {
     protected String marca;
     protected String modelo;
     protected int anio;
     protected String tipoCombustible;
     protected String placa;
     protected double posicion=0;
     protected double cilindraje;

    public Vehiculo(String marca, String modelo, int anio, String tipoCombustible, String placa, double cilindraje) {
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
        this.tipoCombustible = tipoCombustible;
        this.placa = placa;
        this.cilindraje = cilindraje;
    }
     
     public abstract double calcularVelocidadMaxima();
     public abstract double calcularCostoMantenimiento();
     
     public double getPosicion() {
        return posicion;
    }

}
