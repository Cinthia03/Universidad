package com.mycompany.cinthiatenesacap3;

/**
 *
 * @author Cinth
 */
public interface IntMover {
    public String mover (double distancia);
}
