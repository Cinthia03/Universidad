package com.mycompany.cinthiatenesacap3;

/**
 *
 * @author Cinth
 */
public class Motocicleta extends Vehiculo implements IntMover{

     private String tipo;

    public Motocicleta(String tipo, String marca, String modelo, int anio, String tipoCombustible, String placa, double cilindraje) {
        super(marca, modelo, anio, tipoCombustible, placa, cilindraje);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoCombustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getPosicion() {
        return posicion;
    }

    public void setPosicion(double posicion) {
        this.posicion = posicion;
    }
     
    @Override
    public double calcularVelocidadMaxima() {
        int base = 100;
        return base + (cilindraje * 0.05);
    }
    
    @Override
    public double calcularCostoMantenimiento() {
        int costo = 200;
        return costo + (cilindraje * 0.10);
    }
    
    @Override
    public String mover(double distancia) {
        posicion += distancia;
        return "Automovil en km: " + posicion;
    }
 
}