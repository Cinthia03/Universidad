package com.mycompany.cinthiatenesacap3;

/**
 *
 * @author Cinth
 */
public class Automovil extends Vehiculo implements IntMover{
     String color;
     int numeroPuertas;

    public Automovil(String color, int numeroPuertas, String marca, String modelo, int anio, String tipoCombustible, String placa, double cilindraje) {
        super(marca, modelo, anio, tipoCombustible, placa, cilindraje);
        this.color = color;
        this.numeroPuertas = numeroPuertas;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getNumeroPuertas() {
        return numeroPuertas;
    }

    public void setNumeroPuertas(int numeroPuertas) {
        this.numeroPuertas = numeroPuertas;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoCombustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getPosicion() {
        return posicion;
    }

    public void setPosicion(double posicion) {
        this.posicion = posicion;
    }

    @Override
    public double calcularVelocidadMaxima() {
        int base = 100;
        return base + (cilindraje * 0.03);
    }
    
    @Override
    public double calcularCostoMantenimiento() {
        int base = 200;
        return base + (cilindraje * 0.12);
    }
    
    @Override
    public String mover(double distancia) {
        posicion += distancia;
        return "Automovil en km: " + posicion;
    }
 
}
